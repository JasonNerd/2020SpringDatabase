/**
 * Owned by HITSZ-180110704--Yu-DUan
 * start at 2021-04-29, deadline 2021-05-05
 * breakpoint: 2021-05-03 23:20 fininsh the problem 2 that disscuss how to sort lots of data
 *              while we have a small memory
 *
 */
#include<stdlib.h>
#include<stdio.h>
#include<memory.h>
#include"extmem.h"
#define PROGONE 100
#define ELESIZE 4
#define ATTRNUM 2
#define BLKTUPL 8
#define IMEMBLK 8
#define FIRSTVAL 100
#define INDEXFILR "data/index_document_R.txt"
#define INDEXFILS "data/index_document_S.txt"
//1、选择S中第一属性为50
int selectSA50(unsigned int start, unsigned int end, Buffer* imem,unsigned int key);
//2、将R和S分别多路归并排序
int tpmms(unsigned int start, unsigned int end, unsigned int output, Buffer imem);
//3、根据排序结果构建索引文件，再次实现1的功能，观察IO次数变化
int index_select_A50(unsigned int start, unsigned int end, Buffer* imem, unsigned int key, char* file_path, unsigned int output);
//根据2的排序结果，模拟select S.C, S.D, R.A, R.B from S inner join R on S.C = R.A
int select_merge_join(unsigned int start_r, unsigned int end_r, unsigned int start_s, unsigned int end_s, unsigned int output, Buffer* imem);
//S与R的交
int intersect_RS(unsigned int start_r, unsigned int end_r, unsigned int start_s, unsigned int end_s, unsigned int output, Buffer* imem);

//辅助功能函数
int print_R(unsigned int blk_start, unsigned int blk_end, Buffer* imem);
void cp_blk_line(unsigned char* blk_i, unsigned char* blk_j);
int toInt(unsigned char* ptr);
void toStr(int a, unsigned char* b);
void toTuple(unsigned char* ptr, int* x, int* y);
void innnerSort(unsigned char* blk_ptr[], int n);
void blk_line_swap(unsigned char* ptr_i, unsigned char* ptr_j);
void tpmms_first_stage(unsigned int start, unsigned int end, unsigned int output, Buffer imem);
void tpmms_second_stage(unsigned int start, unsigned int end, unsigned int output, Buffer imem);
void print_blk(unsigned char* blk);
void clear_mem(Buffer* imem);
int create_index_file(FILE *fp, unsigned int start, unsigned int end, Buffer* imem);

int main(){
    // 初始化一块内存
    Buffer imem;
    if(!initBuffer(520, 64, &imem)){
        perror("Buffer Initialization Failed!\n");
        return -1;
    }
    int choice, flag=0, join_cnt, blk_num, var;
    printf("\t\t        180110704   DBexp4 \n\n\n");
    printf("\t\t        1、从S(17:48)共32×7=224个元组中选出S.A=50的元组\n\n");
    printf("\t\t        2、将R和S分别多路归并排序\n\n");
    printf("\t\t        3、建立索引文件同时选出S.A=50的元组\n\n");
    printf("\t\t        4、对关系S和R计算S.C连接R.A ，并统计连接次数，将连接结果存放在磁盘上\n\n");
    printf("\t\t        5、S与R的交\n\n\n\n");

    while(1){
        printf("请选择：");
        scanf("%d", &choice);
        flag=0;
        switch (choice)
        {
        case 1:
            selectSA50(17, 49, &imem, 50);
            break;
        case 2:
            // tpmms(1, 17, 200, imem);    //对R进行两阶段多路归并
            // tpmms(17, 49, 300, imem);    //对S进行两阶段多路归并
            /* 由于归并后的输出已经写入标准blk文件，故演示时不执行实际操作，而是直接输出结果文件 */
            printf("\n对R进行两阶段多路归并排序：\n");
            print_R(220, 236, &imem);
            printf("\n对S进行两阶段多路归并排序：\n");
            print_R(340, 372, &imem);
            break;
        case 3:
            index_select_A50(340, 372, &imem, 50, INDEXFILS, 150);
            break;
        case 4:
            join_cnt = select_merge_join(220, 236, 340, 372, 400, &imem);
            printf("一共进行%d次连接操作\n", join_cnt);
            var = (2*join_cnt)%(BLKTUPL-2);
            blk_num = (2*join_cnt)/(BLKTUPL-2);
            if(var)blk_num++;
            print_R(400, 400+blk_num, &imem);
            break;
        case 5:
            join_cnt = intersect_RS(220, 236, 340, 372, 520, &imem);//520哟
            printf("R交S一共含%d个元组\n", join_cnt);
            var = join_cnt%(BLKTUPL-1);
            blk_num = join_cnt/(BLKTUPL-1);
            if(var)blk_num++;
            print_R(520, 520+blk_num, &imem);
            break;
        default:
            flag = 1;
            break;
        }
        if(flag)break;
    }
}


int selectSA50(unsigned int start, unsigned int end, Buffer* imem,unsigned int key){
    //S的块序号为17到48
    unsigned int i=start, a, b, j, flag=0;
    unsigned int ok=0, ok_blk=PROGONE;//分别记录符合的记录数(模)，写入第几块
    unsigned char* blk_buffer = getNewBlockInBuffer(imem);
    unsigned char* blkPtr;
    printf("Before using index-technique: S.A=50\n");
    while(1){
        blkPtr = readBlockFromDisk(i, imem);   //read one block from disk
        printf("read the block %d\n", i);
        flag=0;
        for(i=0; i<BLKTUPL-1; i++){   //each block has 7 valid data line
            a = toInt(blkPtr+i*ELESIZE*ATTRNUM);
            b = toInt(blkPtr+i*ELESIZE*ATTRNUM+ELESIZE);
            if(a == key){
                //向输出块缓冲区写入一个元组(注意到未使用else选项，因为第8条数据已经产生了)
                for(j=0; j<ELESIZE*ATTRNUM; j++)
                    blk_buffer[ok*ELESIZE*ATTRNUM+j]=blkPtr[i*ELESIZE*ATTRNUM+j];
                printf("(%d, %d) ", a, b);
                ++ok;
                flag=1;
                if(ok == BLKTUPL-1){
                    //此时输出缓冲块数据区已满，应当填充指针并写入磁盘
                    printf("\n\nwirte to disk block %d\n\n", ok_blk);
                    toStr(ok_blk+1, blk_buffer+(ok+1)*ELESIZE*ATTRNUM);
                    writeBlockToDisk(blk_buffer, ok_blk, imem);//写入后自动释放
                    blk_buffer = getNewBlockInBuffer(imem);//此时再次申请一块内存区域作为缓冲buffer
                    ok=0;//ok归0
                    ok_blk++;
                }
            }
        }
        if(flag)printf("\n");
        freeBlockInBuffer(blkPtr, imem);   //the block have been used, release it immediately
        //get the next block index
        i = toInt(blkPtr+(BLKTUPL-1)*ELESIZE*ATTRNUM);
        if(i == end)
            break;  //end of S
    }
    //输出缓冲区可能还有残余数据，也要一并写入磁盘
    printf("\n\nwirte to disk block %d\n\n", ok_blk);
    toStr(ok_blk+1, blk_buffer+(ok)*ELESIZE*ATTRNUM);
    writeBlockToDisk(blk_buffer, ok_blk, imem);//写入后自动释放
    printf("IO cnt: %ld\n", imem->numIO);
    printf("%d tupples correspond\n", ok+(BLKTUPL-1)*(ok_blk-PROGONE));//计算公式：完整的块数*每块元组数+剩余的元组数
    clear_mem(imem);
    return 0;
}

int tpmms(unsigned int start, unsigned int end, unsigned int output, Buffer imem){
    //在内存缓冲区利用多路归并排序对块start到end-1的块的排序，假定不超过64块
    tpmms_first_stage(start, end, output, imem);
    /*假定没有剩余的块，例如16和32，恰好是8的倍数，如果是49或者其它不是8的倍数，则需要
     *对余下的磁盘块单独处理
    */
    //第二阶段归并排序，需要先把输入输出变一下
    end = output+(end-start);
    start = output;
    output = output+((end-start)/10+1)*10;
    tpmms_second_stage(start, end, output, imem);

    return 0;
}

int index_select_A50(unsigned int start, unsigned int end, Buffer* imem, unsigned int key, char* file_path, unsigned int output){
    //读取索引文件, 若没有则创建索引文件
    FILE *fp;
    fp = fopen(file_path, "r");
    if(!fp){
        printf("There's no index document, now creating ...\n");
        fp = fopen(file_path, "w");
        create_index_file(fp, start, end, imem);
        fclose(fp);
        fp = fopen(file_path, "r");
    }
    //根据索引查找需要遍历的块的范围
    int blk_ind, blk_head, sl_start, sl_end;
    while(!feof(fp)){
        fscanf(fp, "%d %d", &blk_ind, &blk_head);
        if(blk_head < key){
            sl_start = blk_ind;
            sl_end = sl_start;
        }else{
            if(blk_head == key)
                sl_end = blk_ind;
        }
    }
    //对[sl_start, sl_end]内的块进行遍历
    unsigned char *blk_ptr, *bptr_j, *optr_j;
    unsigned char* out_buffer_blk = getNewBlockInBuffer(imem);
    int i, j, val_x, val_y, out_line=0, out_blk=0;
    for(i=sl_start; i<sl_end+1; i++){
        printf("Read Block %d\n", i);
        blk_ptr = readBlockFromDisk(i, imem);
        for(j=0; j<BLKTUPL-1; j++){
            bptr_j = blk_ptr+j*ELESIZE*ATTRNUM;
            val_x = toInt(bptr_j);
            val_y = toInt(bptr_j+ELESIZE);
            //与键值比较，结果写入缓冲区
            if(val_x == key){
                printf("(%d, %d) ", val_x, val_y);
                optr_j = out_buffer_blk+out_line*ATTRNUM*ELESIZE;
                cp_blk_line(bptr_j, optr_j);
                out_line++;
                if(out_line == BLKTUPL-1){
                    //缓冲区满，写入磁盘
                    optr_j = out_buffer_blk+out_line*ATTRNUM*ELESIZE;
                    toStr(output+out_blk+1, optr_j);
                    printf("buffer is full, write to disk block %d\n", output+out_blk);
                    writeBlockToDisk(out_buffer_blk, output+out_blk, imem);
                    memset(out_buffer_blk, 0, BLKTUPL*ATTRNUM*ELESIZE*sizeof(unsigned char));
                    out_buffer_blk = getNewBlockInBuffer(imem);
                    out_blk++;
                    out_line = 0;
                }

            }
        }
    }
    //残余数据写入磁盘
    optr_j = out_buffer_blk+out_line*ATTRNUM*ELESIZE;
    toStr(output+out_blk+1, optr_j);
    printf("some rest data in buffer, write to disk block %d\n", output+out_blk);
    writeBlockToDisk(out_buffer_blk, output+out_blk, imem);
    printf("IO cnt: %ld\n", imem->numIO);
    printf("%d tupples correspond\n", out_blk*(IMEMBLK-1)+out_line);//计算公式：完整的块数*每块元组数+剩余的元组数
    //收尾工作
    clear_mem(imem);
    fclose(fp);
    return 0;
}

int select_merge_join(unsigned int start_r, unsigned int end_r, unsigned int start_s, unsigned int end_s, unsigned output, Buffer* imem){
    //根据2的排序结果，模拟select S.C, S.D, R.A, R.B from S inner join R on S.C = R.A
    /*思路：
    遍历R和S，同时可以按块操作，不需要细分到块的数据行，同时但凡有一个关系遍历完，那就可以收工
    另外，考虑到块数据连续存储且有序，故设立头数据和尾数据，在一个块的头比另一个的尾还大时，可以直接跳过小尾块
    这种做法在某些数据集上可能具有更优的性能(稀疏，间距大)
    */
    int head_r, tail_r, head_s, tail_s, out_line=0, out_blk=0, i, j;
    int val_r, val_s, join_cnt=0, in_i, in_j;
    int bias = (BLKTUPL-2)*ATTRNUM*ELESIZE;
    unsigned char *blk_ptr_r, *blk_ptr_s, *bp_rj, *bp_sj, *out_blk_ptr, *optr_j;
    out_blk_ptr = getNewBlockInBuffer(imem);
    optr_j = out_blk_ptr;
    //开启循环
    for(i=start_r; i<end_r; i++){
        blk_ptr_r = readBlockFromDisk(i, imem);
        // printf("\ni-loop: read block %d\n", i);
        for(j=start_s; j<end_s; j++){
            blk_ptr_s = readBlockFromDisk(j, imem);
            // printf("\tj-loop: read block %d\n", j);
            //head-tail加速
            head_r = toInt(blk_ptr_r);
            tail_r = toInt(blk_ptr_r+bias);
            head_s = toInt(blk_ptr_s);
            tail_s = toInt(blk_ptr_s+bias);
            if(head_r > tail_s){
                freeBlockInBuffer(blk_ptr_s, imem);
                memset(blk_ptr_s, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
                continue;//由于S是内层循环，故仅结束本次循环
            }
            if(head_s > tail_r){
                freeBlockInBuffer(blk_ptr_s, imem);
                memset(blk_ptr_s, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
                break;//由于R是外层循环，条件成立则不必进行内循环
            }
            
            // printf("\t\tNot accelerate: intersection between %d.blk and %d.blk\n", i, j);
            for(in_i=0; in_i<(BLKTUPL-1)*ATTRNUM*ELESIZE; in_i+=ATTRNUM*ELESIZE){
                bp_rj = blk_ptr_r + in_i;
                val_r = toInt(bp_rj);
                // printf("\t\tval_r=%d\n", val_r);
                for(in_j=0; in_j<(BLKTUPL-1)*ATTRNUM*ELESIZE; in_j+=ATTRNUM*ELESIZE){
                    bp_sj = blk_ptr_s + in_j;
                    val_s = toInt(bp_sj);
                    // printf("\t\t\tval_s=%d\n", val_s);
                    if(val_r == val_s){ //注意到由于每次写入2个元组，为了方便，一个块只存6个元组
                        ++join_cnt;
                        
                        cp_blk_line(bp_sj, optr_j);
                        optr_j += ELESIZE*ATTRNUM;
                        out_line++;
                        cp_blk_line(bp_rj, optr_j);
                        optr_j += ELESIZE*ATTRNUM;
                        out_line++;
                        //判断缓冲区是否满，这里6个元组即为满
                        if(out_line == BLKTUPL - 2){
                            toStr(out_blk+output+1, optr_j);
                            writeBlockToDisk(out_blk_ptr, out_blk+output, imem);
                            // printf("\t\t\tWrite to %d.blk\n", out_blk+output);
                            memset(out_blk_ptr, 0, sizeof(unsigned char)*BLKTUPL*ATTRNUM*ELESIZE);
                            out_blk_ptr = getNewBlockInBuffer(imem);
                            out_blk++;
                            out_line = 0;
                            optr_j = out_blk_ptr;
                        }
                    }
                }
            }
            freeBlockInBuffer(blk_ptr_s, imem);
            memset(blk_ptr_s, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
        }
        freeBlockInBuffer(blk_ptr_r, imem);
        memset(blk_ptr_r, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
    }
    //同样的要把输出缓冲区的剩余部分写入外磁盘
    toStr(out_blk+output+1, optr_j);
    writeBlockToDisk(out_blk_ptr, out_blk+output, imem);
    clear_mem(imem);
    return join_cnt;
}

int intersect_RS(unsigned int start_r, unsigned int end_r, unsigned int start_s, unsigned int end_s, unsigned output, Buffer* imem){
    //这里是求R和S的交集，实际上和select_merge_join完全一样，只不过要求两个元组的分量对应相等
    //然后就是BLK仍为7个元组
    int head_r, tail_r, head_s, tail_s, out_line=0, out_blk=0, i, j;
    int val_r, val_s, join_cnt=0, in_i, in_j;
    int bias = (BLKTUPL-2)*ATTRNUM*ELESIZE;
    unsigned char *blk_ptr_r, *blk_ptr_s, *bp_rj, *bp_sj, *out_blk_ptr, *optr_j;
    out_blk_ptr = getNewBlockInBuffer(imem);
    optr_j = out_blk_ptr;
    //开启循环
    for(i=start_r; i<end_r; i++){
        blk_ptr_r = readBlockFromDisk(i, imem);
        for(j=start_s; j<end_s; j++){
            blk_ptr_s = readBlockFromDisk(j, imem);
            //head-tail加速
            head_r = toInt(blk_ptr_r);
            tail_r = toInt(blk_ptr_r+bias);
            head_s = toInt(blk_ptr_s);
            tail_s = toInt(blk_ptr_s+bias);
            if(head_r > tail_s){
                freeBlockInBuffer(blk_ptr_s, imem);
                memset(blk_ptr_s, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
                continue;//由于S是内层循环，故仅结束本次循环
            }
            if(head_s > tail_r){
                freeBlockInBuffer(blk_ptr_s, imem);
                memset(blk_ptr_s, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
                break;//由于R是外层循环，条件成立则不必进行内循环
            }
            for(in_i=0; in_i<(BLKTUPL-1)*ATTRNUM*ELESIZE; in_i+=ATTRNUM*ELESIZE){
                bp_rj = blk_ptr_r + in_i;
                val_r = toInt(bp_rj);
                for(in_j=0; in_j<(BLKTUPL-1)*ATTRNUM*ELESIZE; in_j+=ATTRNUM*ELESIZE){
                    bp_sj = blk_ptr_s + in_j;
                    val_s = toInt(bp_sj);
                    if((val_r == val_s) && (toInt(bp_rj+ELESIZE) == toInt(bp_sj+ELESIZE))){
                        ++join_cnt;
                        cp_blk_line(bp_sj, optr_j);
                        optr_j += ELESIZE*ATTRNUM;
                        out_line++;
                        if(out_line == BLKTUPL - 1){
                            toStr(out_blk+output+1, optr_j);
                            writeBlockToDisk(out_blk_ptr, out_blk+output, imem);
                            // printf("\t\t\tWrite to %d.blk\n", out_blk+output);
                            memset(out_blk_ptr, 0, sizeof(unsigned char)*BLKTUPL*ATTRNUM*ELESIZE);
                            out_blk_ptr = getNewBlockInBuffer(imem);
                            out_blk++;
                            out_line = 0;
                            optr_j = out_blk_ptr;
                        }
                    }
                }
            }
            freeBlockInBuffer(blk_ptr_s, imem);
            memset(blk_ptr_s, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
        }
        freeBlockInBuffer(blk_ptr_r, imem);
        memset(blk_ptr_r, 0, BLKTUPL*ELESIZE*ATTRNUM*sizeof(unsigned char));
    }
    //同样的要把输出缓冲区的剩余部分写入外磁盘
    toStr(out_blk+output+1, optr_j);
    writeBlockToDisk(out_blk_ptr, out_blk+output, imem);
    clear_mem(imem);
    return join_cnt;
}

int create_index_file(FILE *fp, unsigned int start, unsigned int end, Buffer* imem){
    unsigned int i;
    int head;
    unsigned char* blk_ptr;
    for(i=start; i<end; i++){
        blk_ptr = readBlockFromDisk(i, imem);
        head = toInt(blk_ptr);
        if(i==end-1)
            fprintf(fp, "%d %d", i, head);
        else
            fprintf(fp, "%d %d\n", i, head);
        freeBlockInBuffer(blk_ptr, imem);
    }
    clear_mem(imem);
    return 0;
}

void tpmms_first_stage(unsigned int start, unsigned int end, unsigned int output, Buffer imem){
    int blk_num = end - start;  // 待排序的数据块块数，8块一组
    int grps = blk_num/IMEMBLK; // 分组的数目，如果有20块，那么还是2组，剩下的单独处理
    //第一阶段，将每一个小组进行内排序
    int i;
    unsigned int blk_start, blk_end, blk_ind;
    //printf("Block number: %d\n  groups: %d\n\n", blk_num, grps);
    for(i=0; i<grps; i++){
        blk_start = start + i*IMEMBLK;
        blk_end = blk_start + IMEMBLK;
        //printf("loop %d, start:%d, end: %d\n", i, blk_start, blk_end);
        unsigned char** blk_ptr; //动态申请
        blk_ptr = (unsigned char**)(malloc(sizeof(unsigned char*)*IMEMBLK));
        //printf("imem_ptr: %p\n", blk_ptr);
        for(blk_ind=blk_start; blk_ind<blk_end; blk_ind++){
            //读入内存，并存放每一个块的起始地址
            blk_ptr[blk_ind-blk_start]=readBlockFromDisk(blk_ind, &imem);
        }
        //将blk_ptr[8]看作一个一维数组，进行原址排序（也即不申请使用新的内存）
        //排序结束则有8个块有序，再依次写入内存即可
        innnerSort(blk_ptr, IMEMBLK);
        //写结果
        for(blk_ind=output; blk_ind<output+IMEMBLK; blk_ind++){
            //依次写入外存
            writeBlockToDisk(blk_ptr[blk_ind-output], blk_ind+i*IMEMBLK, &imem);
        }
        //写完后内存块自动恢复，可以立即进行下一轮
    }
    clear_mem(&imem);
}

void tpmms_second_stage(unsigned int start, unsigned int end, unsigned int output, Buffer imem){
    //从start 到 end 每8个块一组(56个有序元组)一共2组或4组进行多路归并
    unsigned int grps = (end-start)/IMEMBLK;
    unsigned char *blk_grps_ptr[grps], *ptr_i, *blk_grps_base_ptr[grps];
    unsigned int blk_grps_ind[grps], blk_grps_base[grps];
    int i;
    for(i=0; i<grps; i++){
        blk_grps_base[i] = blk_grps_ind[i] = start+i*IMEMBLK;
        blk_grps_base_ptr[i] = blk_grps_ptr[i] = readBlockFromDisk(blk_grps_base[i], &imem);
        //print_blk(blk_grps_ptr[i]);
        //printf("\n");
    }
    unsigned char *out_blk = getNewBlockInBuffer(&imem), *out_blk_ptr;
    memset(out_blk, 0, sizeof(unsigned char)*ELESIZE*ATTRNUM*BLKTUPL);
    out_blk_ptr = out_blk;
    int min_ele = FIRSTVAL, min_ind=0, val_i, val_x, val_d;
    unsigned int out_hav=0, out_ind, blk_ok=0;
    //以上代码将每组的第一块读入内存，同时申请了一块未使用的block作为缓冲区
    while (1){
        //寻找最小值
        for(i=0; i<grps; i++){
            ptr_i = blk_grps_ptr[i];
            val_i = toInt(ptr_i);
            if(min_ele > val_i){
                min_ele = val_i;
                min_ind = i;
            }
        }
        if(min_ele >= FIRSTVAL){
            printf("Merge sort over!\n");
            break;
        }
        printf("grp[%d]: ", min_ind);
        val_x = toInt(blk_grps_ptr[min_ind]+ELESIZE);
        printf("min_tuple=(%d, %d)\n", min_ele, val_x);
        //将最小值写入out_blk
        if(val_x){//val_x=0表示这一行是指针行，那么寻找最小值这一步作废
            cp_blk_line(blk_grps_ptr[min_ind], out_blk_ptr);
            out_hav++;  //表示输出缓冲已用行数加1
            out_blk_ptr+=ELESIZE*ATTRNUM;
        }
        //如果输出缓冲区满则重新初始化一个输出缓冲区
        if(out_hav == BLKTUPL-1){
            out_ind = output + blk_ok;
            toStr(out_ind+1, out_blk_ptr);
            printf("Write to disk, block No.%d\n", out_ind);
            writeBlockToDisk(out_blk, out_ind, &imem);
            out_blk = getNewBlockInBuffer(&imem);
            memset(out_blk, 0, sizeof(unsigned char)*ELESIZE*ATTRNUM*BLKTUPL);
            out_hav = 0;
            out_blk_ptr = out_blk;
            blk_ok++;
        }
        //对于min_ind对应的块指针，需要对其进行移动，注意如果当前块结束，则
        if(val_x){
            //直接移动指针即可
            blk_grps_ptr[min_ind] += ELESIZE*ATTRNUM;
        }else{
            //当前块内的数据已读取完毕，释放该块，清空并重新读取下一块
            freeBlockInBuffer(blk_grps_base_ptr[min_ind], &imem);
            memset(blk_grps_base_ptr[min_ind], 0, sizeof(unsigned char)*ELESIZE*ATTRNUM*BLKTUPL);
            blk_grps_ind[min_ind]++;
            val_d = blk_grps_ind[min_ind] - blk_grps_base[min_ind];
            if(val_d >= IMEMBLK){
                printf("Group %d is over now!\n", min_ind);
                toStr(FIRSTVAL+1, blk_grps_ptr[min_ind]);//不移动指针，而是修改其中的值为101，作为结束判断条件
                printf("blk_grps_ptr[min_ind] = %d ", toInt(blk_grps_ptr[min_ind]));
            }else{
                // printf("grp[0]:%p, grp[1]:%p\n", blk_grps_ptr[0], blk_grps_ptr[1]);
                // printf("grp[1]: %d\n", toInt(blk_grps_ptr[1]));
                blk_grps_base_ptr[min_ind] = readBlockFromDisk(blk_grps_ind[min_ind], &imem);
                blk_grps_ptr[min_ind] = blk_grps_base_ptr[min_ind];
                printf("Read new block %d: \n", blk_grps_ind[min_ind]);
                print_blk(blk_grps_ptr[min_ind]);
                printf("\n");
            }
        }
        min_ele = FIRSTVAL;
    }
    clear_mem(&imem);
}

void innnerSort(unsigned char* blk_ptr[], int n){
    //辅助内排序函数，输入为一个内存数据结构，n为数组长度
    unsigned char *ptr_i, *ptr_j;
    int shift_i=0, shift_j=0, bais_i, bais_j;
    //在这里，每个数据块都是满的，也即都存放着7个元组，不会出现某个块存放元组数目少于7个
    //printf("In function innerSort: n=%d, head=%d \n", n, toInt(blk_ptr[0]));
    for(ptr_i=blk_ptr[shift_i]; ; ){
        bais_i = toInt(ptr_i+ELESIZE*ATTRNUM+ELESIZE);  //指向的是下一block行的第二属性
        if(bais_i==0){
            //bias_i==0代表当前块即将结束
            shift_i++;
            if(shift_i == n)
                break;
            ptr_j = blk_ptr[shift_i];
        }else{
            ptr_j = ptr_i+ELESIZE*ATTRNUM;
        }
        for(shift_j=shift_i ; ; ){
            bais_j = toInt(ptr_j+ELESIZE);
            if(bais_j == 0){
                //bias_j==0代表当前块已结束
                shift_j++;
                if(shift_j == n)
                    break;
                ptr_j = blk_ptr[shift_j];
                continue;
            }
            if(toInt(ptr_i) > toInt(ptr_j)){
                blk_line_swap(ptr_i, ptr_j);
            }
            ptr_j+=ELESIZE*ATTRNUM;
        }
        //printf("The turn: %d \n\n", toInt(ptr_i));
        if(bais_i==0)
            ptr_i = blk_ptr[shift_i];
        else
            ptr_i+=ELESIZE*ATTRNUM;
    }

}

void blk_line_swap(unsigned char* ptr_i, unsigned char* ptr_j){
    int i=0;
    unsigned char tmp[ELESIZE*ATTRNUM];
    for(i=0; i<ELESIZE*ATTRNUM; i++)
        tmp[i]=ptr_i[i];
    for(i=0; i<ELESIZE*ATTRNUM; i++)
        ptr_i[i]=ptr_j[i];
    for(i=0; i<ELESIZE*ATTRNUM; i++)
        ptr_j[i]=tmp[i];
}

int toInt(unsigned char* ptr){
    char a[ELESIZE+1];
    a[ELESIZE]=0;
    int i;
    for(i=0; i<ELESIZE; i++){
        a[i] = ptr[i];
    }
    return atoi(a);
}

void toStr(int a, unsigned char* b){
    // 辅助函数，假定a是一个三位数的正整数，b是8字节的block line
    int i;
    for(i=ELESIZE-1; i<ATTRNUM*ELESIZE; i++)
        b[i]=0;
    b[2]=a%10+'0';
    b[1]=(a/10)%10+'0';
    b[0]=a/100+'0';
}

void cp_blk_line(unsigned char* blk_i, unsigned char* blk_j){
    // 将块指针blk_i指向的元组(line)复制到blk_j里
    unsigned int i=0;
    for(i=0; i<ELESIZE*ATTRNUM; i++)
        blk_j[i] = blk_i[i];
    return;
}

int print_R(unsigned int blk_start, unsigned int blk_end, Buffer *imem){
    // attempt to print all the tupple in from block blk_start to blk_end
    // a block: you can treat it like a byte array, and each block
    // can be distinguished by a byte pointer
    unsigned int blk_index;
    unsigned char* blk;
    for(blk_index=blk_start; blk_index<blk_end; blk_index++){
        printf("\tBlock %d: \n", blk_index);
        blk = readBlockFromDisk(blk_index, imem);
        print_blk(blk);
        freeBlockInBuffer(blk, imem);
        printf("\n");
    }
    clear_mem(imem);
    return 0;
}

void print_blk(unsigned char* blk){
    unsigned int i;
    for(i=0; i<(IMEMBLK-1)*ATTRNUM*ELESIZE; i+=ATTRNUM*ELESIZE){
        if(toInt(blk+i+ELESIZE))
            printf("(%d, %d) ", toInt(blk+i), toInt(blk+i+ELESIZE));
        else
            break;
    }
}

void toTuple(unsigned char* ptr, int* x, int* y){
    char str[ELESIZE+1];
    int k;
    for(k=0; k<ELESIZE; k++)
        str[k]=ptr[k];
    *x= atoi(str);
    for(k=0; k<ELESIZE; k++)
        str[k]=ptr[k+ELESIZE];
    *y= atoi(str);
}

void clear_mem(Buffer* imem){
    memset(imem->data, 0, (IMEMBLK*BLKTUPL+1)*ATTRNUM*ELESIZE*sizeof(unsigned char));
    imem->numAllBlk = IMEMBLK;
    imem->numFreeBlk = IMEMBLK;
    imem->numIO = 0;
}

